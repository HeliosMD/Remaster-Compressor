./compile.sh
sudo cp rms /usr/bin/rms
sudo cp peak /usr/bin/peak
sudo cp wav_header /usr/bin/wav_header
sudo cp sin-comp /usr/bin/sin-comp
sudo cp bulk-compressor /usr/bin/bulk-compressor
sudo cp remaster-compressor.sh /usr/bin/remaster-compressor
sudo cp remaster-compressor.sh /usr/bin/remaster-compressor.sh
